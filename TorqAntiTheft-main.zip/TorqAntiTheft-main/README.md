![Logo](TORQ.png)
# Torq Anti-Theft System
A STM32 Powered Anti Theft System


Francesco Balassone M63001645

Luca Pisani M63001627


Prof. Mario Barbareschi

Architettura e Progetto dei Calcolatori (Computer Systems Design)
